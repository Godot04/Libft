
#include "my_utils.h"

create_test_val(tolower);

int	main()
{
	handle_signals_with_time();
	test(tolower);
}
