
#include "my_utils.h"

create_test_ctype(isprint);

int	main()
{
	handle_signals_with_time();
	test(isprint);
}
