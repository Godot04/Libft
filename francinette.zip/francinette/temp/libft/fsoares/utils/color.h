#ifndef COLOR_H_
#define COLOR_H_

#define BRED   "\x1B[1;31m"
#define RED    "\x1B[0;31m"
#define BGRN   "\x1B[1;32m"
#define GRN   "\x1B[0;32m"
#define YEL   "\x1B[0;33m"
#define BLU   "\x1B[0;34m"
#define BMAG   "\x1B[1;35m"
#define MAG   "\x1B[0;35m"
#define CYN   "\x1B[0;36m"
#define BCYN   "\x1B[1;36m"
#define BWHT   "\x1B[1;37m"
#define NC    "\x1B[0m"

#endif