#include "my_utils.h"

create_test_ctype(isalpha);

int	main()
{
	handle_signals_with_time();
	test(isalpha);
}
