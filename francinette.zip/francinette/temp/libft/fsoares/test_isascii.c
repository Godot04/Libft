
#include "my_utils.h"

create_test_ctype(isascii);

int	main()
{
	handle_signals_with_time();
	test(isascii);
}
