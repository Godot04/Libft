
#include "my_utils.h"

create_test_val(toupper);

int	main()
{
	handle_signals_with_time();
	test(toupper);
}
