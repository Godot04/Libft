
#include "my_utils.h"

create_test_ctype(isalnum);

int	main()
{
	handle_signals_with_time();
	test(isalnum);
}
