
#include "my_utils.h"

create_test_ctype(isdigit);

int	main()
{
	handle_signals_with_time();
	test(isdigit);
}
